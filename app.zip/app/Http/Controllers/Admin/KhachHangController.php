<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DichVuLe;
use App\Models\DichVuTrongHopDong;
use App\Models\Concept;
use App\Models\HopDong;
use App\Models\KhachHang;
use App\Models\NhanVien;
use App\Models\NhomDichVu;
use App\Models\TrangPhuc;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Carbon;

class KhachHangController extends Controller
{
    /** Đơn tối thiểu (VNĐ) để áp dụng giảm giá giới thiệu. */
    private const GIOI_THIEU_DON_TOI_THIEU = 300_000;

    /** Số tiền giảm (VNĐ) khi mã giới thiệu hợp lệ và đơn đạt ngưỡng. */
    private const GIOI_THIEU_SO_TIEN_GIAM = 300_000;

    public function dichVuTrongHopDong(HopDong $hopDong)
    {
        $rows = DichVuTrongHopDong::query()
            ->where('dich_vu_trong_hop_dong.id_hop_dong', $hopDong->id)
            ->join('dich_vu_le', 'dich_vu_le.id', '=', 'dich_vu_trong_hop_dong.id_dich_vu')
            ->select([
                'dich_vu_trong_hop_dong.id',
                'dich_vu_trong_hop_dong.id_hop_dong',
                'dich_vu_trong_hop_dong.id_dich_vu',
                'dich_vu_trong_hop_dong.gia_goc',
                'dich_vu_trong_hop_dong.gia_thuc',
                'dich_vu_trong_hop_dong.so_luong',
                'dich_vu_trong_hop_dong.thanh_tien',
                'dich_vu_trong_hop_dong.ghi_chu',
                'dich_vu_le.ten_dich_vu',
                'dich_vu_le.ma_dich_vu',
            ])
            ->orderBy('dich_vu_trong_hop_dong.id')
            ->get();

        return response()->json([
            'data' => $rows,
        ]);
    }

    /**
     * Kiểm tra mã giới thiệu: dùng mã hợp đồng (hop_dong.ma_hop_dong).
     */
    public function kiemTraMaGioiThieu(Request $request)
    {
        $validated = $request->validate([
            'nguoi_gioi_thieu' => 'required|string|max:255',
            'hop_dong_id' => 'nullable|integer|exists:hop_dong,id',
            'tong_tien' => 'nullable|numeric|min:0',
        ]);

        $ma = trim((string) $validated['nguoi_gioi_thieu']);
        $excludeHopDongId = isset($validated['hop_dong_id']) ? (int) $validated['hop_dong_id'] : null;
        $tongTien = (float) ($validated['tong_tien'] ?? 0);

        if ($ma === '') {
            return response()->json([
                'matched' => false,
                'so_tien_giam_gia' => 0,
                'message' => 'Vui lòng nhập mã hợp đồng (ma_hop_dong) người giới thiệu.',
            ]);
        }

        $matched = $this->nguoiGioiThieuKhopMaHopDong($ma, $excludeHopDongId);

        if (! $matched) {
            return response()->json([
                'matched' => false,
                'so_tien_giam_gia' => 0,
                'message' => 'Không tìm thấy hợp đồng có mã '.$ma.'.',
            ]);
        }

        if ($tongTien < self::GIOI_THIEU_DON_TOI_THIEU) {
            return response()->json([
                'matched' => true,
                'so_tien_giam_gia' => 0,
                'message' => 'Mã hợp lệ. Giảm '.number_format(self::GIOI_THIEU_SO_TIEN_GIAM, 0, ',', '.').'đ chỉ áp dụng khi tổng đơn từ '.number_format(self::GIOI_THIEU_DON_TOI_THIEU, 0, ',', '.').'đ trở lên.',
            ]);
        }

        return response()->json([
            'matched' => true,
            'so_tien_giam_gia' => (float) self::GIOI_THIEU_SO_TIEN_GIAM,
            'message' => 'Mã hợp lệ. Đã áp dụng giảm '.number_format(self::GIOI_THIEU_SO_TIEN_GIAM, 0, ',', '.').'đ.',
        ]);
    }

    public function index()
    {
        return redirect()->route('admin.khach-hang.danh-sach');
    }

    public function danhSach(Request $request)
    {
        $search = $request->get('search');

        $danhSach = KhachHang::query()
            ->when($search, function ($q) use ($search) {
                $q->where('ho_ten_chu_re', 'like', "%{$search}%")
                    ->orWhere('ho_ten_co_dau', 'like', "%{$search}%")
                    ->orWhere('email_hoac_sdt_chu_re', 'like', "%{$search}%")
                    ->orWhere('email_hoac_sdt_co_dau', 'like', "%{$search}%")
                    ->orWhere('dia_chi_chu_re', 'like', "%{$search}%")
                    ->orWhere('dia_chi_co_dau', 'like', "%{$search}%")
                    ->orWhere('ghi_chu', 'like', "%{$search}%")
                    ->orWhere('nguon_khach', 'like', "%{$search}%");
            })
            ->orderBy('id')
            ->paginate(15)
            ->withQueryString();

        return view('admin.khach-hang.danh-sach', compact('danhSach'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'ho_ten_chu_re' => 'nullable|string|max:255',
            'ngay_sinh_chu_re' => 'nullable|date',
            'gioi_tinh_chu_re' => 'nullable|string|in:nam,nu,khac',
            'email_hoac_sdt_chu_re' => 'nullable|string|max:255',
            'dia_chi_chu_re' => 'nullable|string',
            'ho_ten_co_dau' => 'nullable|string|max:255',
            'ngay_sinh_co_dau' => 'nullable|date',
            'gioi_tinh_co_dau' => 'nullable|string|in:nam,nu,khac',
            'dia_chi_co_dau' => 'nullable|string',
            'email_hoac_sdt_co_dau' => 'nullable|string|max:255',
            'ghi_chu' => 'nullable|string',
            'nguon_khach' => 'nullable|string|max:2000',
        ]);

        KhachHang::create($validated);

        return redirect()->route('admin.khach-hang.danh-sach')->with('success', 'Đã thêm khách hàng thành công.');
    }

    public function update(Request $request, KhachHang $khachHang)
    {
        $validated = $request->validate([
            'ho_ten_chu_re' => 'nullable|string|max:255',
            'ngay_sinh_chu_re' => 'nullable|date',
            'gioi_tinh_chu_re' => 'nullable|string|in:nam,nu,khac',
            'email_hoac_sdt_chu_re' => 'nullable|string|max:255',
            'dia_chi_chu_re' => 'nullable|string',
            'ho_ten_co_dau' => 'nullable|string|max:255',
            'ngay_sinh_co_dau' => 'nullable|date',
            'gioi_tinh_co_dau' => 'nullable|string|in:nam,nu,khac',
            'dia_chi_co_dau' => 'nullable|string',
            'email_hoac_sdt_co_dau' => 'nullable|string|max:255',
            'ghi_chu' => 'nullable|string',
            'nguon_khach' => 'nullable|string|max:2000',
        ]);

        $khachHang->update($validated);

        return redirect()->route('admin.khach-hang.danh-sach')->with('success', 'Đã cập nhật khách hàng thành công.');
    }

    public function destroy(KhachHang $khachHang)
    {
        $khachHang->delete();
        return redirect()->route('admin.khach-hang.danh-sach')->with('success', 'Đã xóa khách hàng thành công.');
    }
    public function hopDong(Request $request)
    {
        $search = $request->get('search');
        $danhSach = HopDong::query()
            ->with(['khachHang', 'nguoiTao', 'thoChup.user', 'thoMake.user', 'thoEdit.user'])
            ->when($search, function ($q) use ($search) {
                $q->where(function ($w) use ($search) {
                    $w->where('ma_hop_dong', 'like', "%{$search}%")
                        ->orWhereHas('khachHang', function ($q2) use ($search) {
                            $q2->where('ho_ten_chu_re', 'like', "%{$search}%")
                                ->orWhere('ho_ten_co_dau', 'like', "%{$search}%")
                                ->orWhere('email_hoac_sdt_chu_re', 'like', "%{$search}%")
                                ->orWhere('email_hoac_sdt_co_dau', 'like', "%{$search}%");
                        });
                });
            })
            ->orderByDesc('id')
            ->paginate(15)
            ->withQueryString();

        $danhSachKhachHang = KhachHang::query()->orderBy('id')->get();
        $danhSachNhanVien = NhanVien::query()->with('user')->orderBy('id')->get();
        $danhSachNhomDichVu = NhomDichVu::query()
            ->with('dichVuLe')
            ->where('trang_thai', NhomDichVu::TRANG_THAI_HIEN_THI)
            ->orderBy('ten_nhom')
            ->get();
        $danhSachDichVuLe = DichVuLe::query()
            ->where('trang_thai', DichVuLe::TRANG_THAI_HIEN_THI)
            ->orderBy('ten_dich_vu')
            ->get();
        $danhSachConcept = Concept::query()
            ->where('trang_thai', Concept::TRANG_THAI_ACTIVE)
            ->orderBy('ten_concept')
            ->get();

        $danhSachTrangPhuc = TrangPhuc::query()
            ->where('trang_thai', TrangPhuc::TRANG_THAI_ACTIVE)
            ->orderBy('ten_san_pham')
            ->get();

        // Map: trang_phuc_id => ['dd/mm/YYYY', ...] (chỉ các ngày >= hôm nay)
        $today = now()->toDateString();
        $trangPhucSuDungTuHomNay = [];
        $hopDongTuHomNay = HopDong::query()
            ->whereDate('ngay_chup', '>=', $today)
            ->whereNotNull('trang_phuc')
            ->select(['ngay_chup', 'trang_phuc'])
            ->orderBy('ngay_chup')
            ->get();

        foreach ($hopDongTuHomNay as $hd) {
            $raw = (string) ($hd->trang_phuc ?? '');
            $ids = array_filter(array_map('trim', explode(',', $raw)));
            if (empty($ids)) {
                continue;
            }

            $date = null;
            if (! empty($hd->ngay_chup)) {
                try {
                    $date = ($hd->ngay_chup instanceof Carbon)
                        ? $hd->ngay_chup->format('d/m/Y')
                        : Carbon::parse($hd->ngay_chup)->format('d/m/Y');
                } catch (\Throwable $e) {
                    $date = null;
                }
            }
            if ($date === null) {
                continue;
            }

            foreach ($ids as $id) {
                $idInt = (int) $id;
                if ($idInt <= 0) continue;
                $trangPhucSuDungTuHomNay[$idInt] ??= [];
                $trangPhucSuDungTuHomNay[$idInt][$date] = true; // set để unique theo ngày
            }
        }

        // Chuẩn hóa về array ngày (unique + đã sort theo query)
        foreach ($trangPhucSuDungTuHomNay as $id => $dateSet) {
            $trangPhucSuDungTuHomNay[$id] = array_keys($dateSet);
        }

        return view('admin.khach-hang.hop-dong', compact(
            'danhSach',
            'danhSachKhachHang',
            'danhSachNhanVien',
            'danhSachNhomDichVu',
            'danhSachDichVuLe',
            'danhSachConcept',
            'danhSachTrangPhuc',
            'trangPhucSuDungTuHomNay'
        ));
    }

    public function storeHopDong(Request $request)
    {
        // --- Bước 1: Validate và tách dữ liệu hợp đồng vs dịch vụ lẻ ---
        $validated = $request->validate([
            'khach_hang_id' => 'required|exists:khach_hang,id',
            'tho_chup_id' => 'nullable|exists:nhan_vien,id',
            'tho_make_id' => 'nullable|exists:nhan_vien,id',
            'tho_edit_id' => 'nullable|exists:nhan_vien,id',
            'dia_diem' => 'nullable|string|max:255',
            'ngay_chup' => 'nullable|date',
            'trang_phuc' => 'nullable|array',
            'trang_phuc.*' => 'integer|exists:trang_phuc,id',
            'concept' => 'nullable|string',
            'ghi_chu_chup' => 'nullable|string',
            'trang_thai_chup' => 'nullable|string|max:50',
            'tong_tien' => 'nullable|numeric|min:0',
            'nguoi_gioi_thieu' => 'nullable|string|max:255',
            'so_tien_giam_gia' => 'nullable|numeric|min:0',
            'thanh_toan_lan_1' => 'nullable|numeric|min:0',
            'thanh_toan_lan_2' => 'nullable|numeric|min:0',
            'thanh_toan_lan_3' => 'nullable|numeric|min:0',
            'trang_thai_hop_dong' => 'nullable|string|max:50',
            'trang_thai_edit' => 'nullable|string|max:50',
            'link_file_demo' => 'nullable|string|max:500',
            'link_file_in' => 'nullable|string|max:500',
            'ngay_tra_link_in' => 'nullable|date',
            'ngay_hen_tra_hang' => 'nullable|date',
            'dich_vu_le_hop_dong' => 'nullable|array',
            'dich_vu_le_hop_dong.*.dich_vu_le_id' => 'required_with:dich_vu_le_hop_dong|integer|exists:dich_vu_le,id',
            'dich_vu_le_hop_dong.*.gia_goc' => 'nullable|numeric|min:0',
            'dich_vu_le_hop_dong.*.gia_thuc' => 'nullable|numeric|min:0',
            'dich_vu_le_hop_dong.*.so_luong' => 'nullable|integer|min:0',
            'dich_vu_le_hop_dong.*.thanh_tien' => 'nullable|numeric|min:0',
            'dich_vu_le_hop_dong.*.ghi_chu' => 'nullable|string|max:500',
        ]);

        $dichVuLeHopDong = $request->input('dich_vu_le_hop_dong', []);
        unset($validated['dich_vu_le_hop_dong']);

        // Lưu danh sách id trang_phuc vào cột text `hop_dong.trang_phuc` (chuỗi id cách nhau dấu phẩy)
        $trangPhucIds = $validated['trang_phuc'] ?? [];
        $validated['trang_phuc'] = !empty($trangPhucIds) ? implode(',', array_map('intval', (array) $trangPhucIds)) : null;

        $validated['nguoi_tao_id'] = $request->user()?->id;
        $validated['so_tien_giam_gia'] = $this->resolveSoTienGiamGiaFromIntro(
            $validated['nguoi_gioi_thieu'] ?? null,
            null,
            (float) ($validated['tong_tien'] ?? 0)
        );

        // --- Bước 2: Tạo hợp đồng (chỉ thông tin hợp đồng) ---
        $hopDong = HopDong::create($validated);

        // Sinh mã hợp đồng theo quy tắc: ddmmyy + id (vd: 31032612)
        if ($hopDong->id && empty($hopDong->ma_hop_dong)) {
            $hopDong->forceFill([
                'ma_hop_dong' => now()->format('dmy') . $hopDong->id,
            ])->save();
        }

        // --- Bước 3: Chỉ khi đã có id hợp đồng mới thêm dịch vụ lẻ vào bảng dich_vu_trong_hop_dong ---
        if ($hopDong->id && ! empty($dichVuLeHopDong)) {
            foreach ($dichVuLeHopDong as $item) {
                $idDichVu = (int) ($item['dich_vu_le_id'] ?? 0);
                if ($idDichVu <= 0) {
                    continue;
                }

                $soLuong = (int) ($item['so_luong'] ?? 1);
                if ($soLuong < 0) $soLuong = 0;
                $thanhTien = (float) ($item['thanh_tien'] ?? ($item['gia_thuc'] ?? 0));
                DichVuTrongHopDong::updateOrCreate(
                    [
                        'id_hop_dong' => $hopDong->id,
                        'id_dich_vu' => $idDichVu,
                    ],
                    [
                        'gia_goc' => (float) ($item['gia_goc'] ?? 0),
                        'gia_thuc' => (float) ($item['gia_thuc'] ?? 0),
                        'so_luong' => $soLuong,
                        'thanh_tien' => $thanhTien,
                        'ghi_chu' => $item['ghi_chu'] ?? null,
                    ]
                );
            }
        }

        return redirect()->route('admin.khach-hang.hop-dong')->with('success', 'Đã thêm hợp đồng thành công.');
    }

    public function updateHopDong(Request $request, HopDong $hopDong)
    {
        $validated = $request->validate([
            'khach_hang_id' => 'required|exists:khach_hang,id',
            'tho_chup_id' => 'nullable|exists:nhan_vien,id',
            'tho_make_id' => 'nullable|exists:nhan_vien,id',
            'tho_edit_id' => 'nullable|exists:nhan_vien,id',
            'dia_diem' => 'nullable|string|max:255',
            'ngay_chup' => 'nullable|date',
            'trang_phuc' => 'nullable|array',
            'trang_phuc.*' => 'integer|exists:trang_phuc,id',
            'concept' => 'nullable|string',
            'ghi_chu_chup' => 'nullable|string',
            'trang_thai_chup' => 'nullable|string|max:50',
            'tong_tien' => 'nullable|numeric|min:0',
            'nguoi_gioi_thieu' => 'nullable|string|max:255',
            'so_tien_giam_gia' => 'nullable|numeric|min:0',
            'thanh_toan_lan_1' => 'nullable|numeric|min:0',
            'thanh_toan_lan_2' => 'nullable|numeric|min:0',
            'thanh_toan_lan_3' => 'nullable|numeric|min:0',
            'trang_thai_hop_dong' => 'nullable|string|max:50',
            'trang_thai_edit' => 'nullable|string|max:50',
            'link_file_demo' => 'nullable|string|max:500',
            'link_file_in' => 'nullable|string|max:500',
            'ngay_tra_link_in' => 'nullable|date',
            'ngay_hen_tra_hang' => 'nullable|date',
            'dich_vu_le_hop_dong' => 'nullable|array',
            'dich_vu_le_hop_dong.*.dich_vu_le_id' => 'required_with:dich_vu_le_hop_dong|integer|exists:dich_vu_le,id',
            'dich_vu_le_hop_dong.*.gia_goc' => 'nullable|numeric|min:0',
            'dich_vu_le_hop_dong.*.gia_thuc' => 'nullable|numeric|min:0',
            'dich_vu_le_hop_dong.*.so_luong' => 'nullable|integer|min:0',
            'dich_vu_le_hop_dong.*.thanh_tien' => 'nullable|numeric|min:0',
            'dich_vu_le_hop_dong.*.ghi_chu' => 'nullable|string|max:500',
        ]);

        $dichVuLeHopDong = $request->input('dich_vu_le_hop_dong', []);
        unset($validated['dich_vu_le_hop_dong']);

        // Lưu danh sách id trang_phuc vào cột text `hop_dong.trang_phuc` (chuỗi id cách nhau dấu phẩy)
        $trangPhucIds = $validated['trang_phuc'] ?? [];
        $validated['trang_phuc'] = !empty($trangPhucIds) ? implode(',', array_map('intval', (array) $trangPhucIds)) : null;

        $validated['so_tien_giam_gia'] = $this->resolveSoTienGiamGiaFromIntro(
            $validated['nguoi_gioi_thieu'] ?? null,
            (int) $hopDong->id,
            (float) ($validated['tong_tien'] ?? 0)
        );

        $hopDong->update($validated);

        // Cập nhật dịch vụ trong hợp đồng: xóa cũ, thêm lại theo danh sách gửi lên
        DichVuTrongHopDong::where('id_hop_dong', $hopDong->id)->delete();
        if (! empty($dichVuLeHopDong)) {
            foreach ($dichVuLeHopDong as $item) {
                $idDichVu = (int) ($item['dich_vu_le_id'] ?? 0);
                if ($idDichVu <= 0) {
                    continue;
                }

                $soLuong = (int) ($item['so_luong'] ?? 1);
                if ($soLuong < 0) $soLuong = 0;
                $thanhTien = (float) ($item['thanh_tien'] ?? ($item['gia_thuc'] ?? 0));
                DichVuTrongHopDong::create([
                    'id_hop_dong' => $hopDong->id,
                    'id_dich_vu' => $idDichVu,
                    'gia_goc' => (float) ($item['gia_goc'] ?? 0),
                    'gia_thuc' => (float) ($item['gia_thuc'] ?? 0),
                    'so_luong' => $soLuong,
                    'thanh_tien' => $thanhTien,
                    'ghi_chu' => $item['ghi_chu'] ?? null,
                ]);
            }
        }

        return redirect()->route('admin.khach-hang.hop-dong')->with('success', 'Đã cập nhật hợp đồng thành công.');
    }

    public function destroyHopDong(HopDong $hopDong)
    {
        // Xóa tất cả bản ghi dịch vụ trong hợp đồng (id_hop_dong trùng) trước khi xóa hợp đồng
        DichVuTrongHopDong::where('id_hop_dong', $hopDong->id)->delete();
        $hopDong->delete();
        return redirect()->route('admin.khach-hang.hop-dong')->with('success', 'Đã xóa hợp đồng.');
    }

    /**
     * Upload ảnh thanh toán và quay lại trang hợp đồng.
     */
    public function uploadAnhThanhToan(Request $request)
    {
        $validated = $request->validate([
            'hop_dong_id' => 'required|exists:hop_dong,id',
            'lan_thanh_toan' => 'required|in:1,2,3',
            'anh_thanh_toan' => 'nullable|image|max:5120', // 5MB
            'so_tien_thanh_toan' => 'nullable|numeric|min:0',
        ]);

        $hopDong = HopDong::findOrFail($validated['hop_dong_id']);
        $lan = (int) $validated['lan_thanh_toan'];

        $column = 'anh_thanh_toan_' . $lan;
        $columnTien = 'thanh_toan_lan_' . $lan;

        // Nếu có upload ảnh thì mới cập nhật ảnh
        if ($request->hasFile('anh_thanh_toan')) {
            /** @var \Illuminate\Http\UploadedFile $file */
            $file = $request->file('anh_thanh_toan');

            // Lưu file vào storage/app/public/hop-dong/anh-thanh-toan
            $path = $file->store('hop-dong/anh-thanh-toan', 'public');

            // Cập nhật đường dẫn ảnh cho hợp đồng
            $hopDong->{$column} = $path;
        }

        // Nếu có nhập số tiền thì lưu vào đúng lần thanh toán
        if ($request->filled('so_tien_thanh_toan')) {
            $hopDong->{$columnTien} = (float) $validated['so_tien_thanh_toan'];
        }

        $hopDong->save();

        return redirect()
            ->route('admin.khach-hang.hop-dong')
            ->with('success', 'Đã cập nhật thanh toán thành công.');
    }

    private function nguoiGioiThieuKhopMaHopDong(string $ma, ?int $excludeHopDongId = null): bool
    {
        $needle = trim($ma);
        if ($needle === '') {
            return false;
        }

        return HopDong::query()
            ->when($excludeHopDongId, fn ($q) => $q->where('id', '!=', $excludeHopDongId))
            ->where('ma_hop_dong', $needle)
            ->exists();
    }

    private function resolveSoTienGiamGiaFromIntro(?string $nguoiGioiThieu, ?int $excludeHopDongId, float $tongTien): float
    {
        $ma = trim((string) ($nguoiGioiThieu ?? ''));
        if ($ma === '' || $tongTien < self::GIOI_THIEU_DON_TOI_THIEU) {
            return 0.0;
        }
        if (! $this->nguoiGioiThieuKhopMaHopDong($ma, $excludeHopDongId)) {
            return 0.0;
        }

        return (float) self::GIOI_THIEU_SO_TIEN_GIAM;
    }
}
